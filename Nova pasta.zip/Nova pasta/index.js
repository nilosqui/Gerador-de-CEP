var fs = require('fs');
fs.readFile('./amogus.txt', 'utf-8', function (err, data) {
    if(err) 
    console.log("CEP gerado com sucesso!");
    console.log ("79831-431")
    console.log("CEP gerado com sucesso!");
    console.log ("40470-630")
    console.log("CEP gerado com sucesso!");
    console.log ("40321010")
    

});